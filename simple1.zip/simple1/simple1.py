# -*- coding: utf-8 -*-
# Botline-Simpleprotect
from LINEPY import *
from akad.ttypes import *
from multiprocessing import Pool, Process
from datetime import datetime
import time,random,sys,json,codecs,threading,glob,re,os,subprocess

cl = LINE("email@gmail.com", "passwordemail")
cl.log("Auth Token : " + str(cl.authToken))

clas1 = LINE("email@gmail.com", "passwordemail")
clas1.log("Auth Token : " + str(clas1.authToken))

print ("⛇ SUKSES LOGIN ⚈")

oepoll = OEPoll(cl)
mid = cl.getProfile().mid
Amid = clas1.getProfile().mid
Bots = [mid,Amid]
owner = ["u44f0f0537a49dd6db99e1a59d7dc2223"]

def sendMessage(to, text, contentMetadata={}, contentType=0):
	mes = Message()
	mes.to, mes.from_ = to, profile.mid
	mes.text = text
	mes.contentType, mes.contentMetadata = contentType, contentMetadata
	if to not in messageReq:
		messageReq[to] = -1
	messageReq[to] += 1
	print (text)
	
def bot(op):
	try:
		if op.type == 0:
			return
			print (text)
		if op.type == 13:
			if mid in op.param3:
				if op.param2 in Bots or owner:
					cl.acceptGroupInvitation(op.param1)
		if op.type == 15:
			if Amid in op.param3:
				if op.param2 in Bots or owner:
					clas1.acceptGroupInvitation(op.param1)

		if op.type == 19:
			print ("⛇KICK ⚈")
			if op.param3 in mid:
				if op.param2 not in Bots:
					clas1.acceptGroupInvitation(op.param1)
					clas1.kickoutFromGroup(op.param1,[op.param2])
					clas1.inviteIntoGroup(op.param1,[mid])
					cl.acceptGroupInvitation(op.param1)
					clas1.leaveGroup(op.param1)
					cl.inviteIntoGroup(op.param1,[Amid])

		if op.type == 19:
			print ("⛇KICK ⚈")
			if op.param3 in owner:
				if op.param2 not in Bots:
					clas1.acceptGroupInvitation(op.param1)
					clas1.kickoutFromGroup(op.param1,[op.param2])
					clas1.findAndAddContactsByMid(op.param3)
					clas1.inviteIntoGroup(op.param1,[owner])
					clas1.leaveGroup(op.param1)
					cl.inviteIntoGroup(op.param1,[Amid])
					
		if op.type == 32:
			print ("⛇CANCEL ⚈")
			if op.param3 in Amid:
				if op.param2 not in Bots and op.param2 not in owner:
					try:
						cl.kickoutFromGroup(op.param1,[op.param2])
						cl.inviteIntoGroup(op.param1,[Amid])
					except:pass
          
		if op.type == 46:    #auto clear chat bot...
			if op.param2 in Bots:
				cl.removeAllMessages()
				clas1.removeAllMessages()
				    
		if op.type == 26:
			msg = op.message
			if msg.text is None:
				return
			elif msg.text in ["Log","log"]:
				if msg._from in owner:
					cl.sendText(msg.to, "Status Login Aktif..")
		if op.type == 17:
			if op.param2 in Bots:
				return
			ginfo = cl.getGroup(op.param1)
	except Exception as error:
		print ("⛇ ERROR ⚈")
thread2 = threading.Thread()
thread2.daemon = True
thread2.start()
while True:
	try:
		ops = oepoll.singleTrace(count=50)
		if ops is not None:
			for op in ops:
				oepoll.setRevision(op.revision)
				thread = threading.Thread(target=bot, args=(op,))
				thread.start()
	except Exception as e:
		print(e)
